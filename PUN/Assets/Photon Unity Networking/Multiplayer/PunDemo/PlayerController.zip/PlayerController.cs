using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerController : Photon.MonoBehaviour {
	public float speed;
	public Animation _anim;
	private PhotonView myPhotonView;

	private string userIdInput = "";

	private string inputLine = "";

	public Text _ChatBox; 

	public Text _PlayerName;
	public Text _MessageDisplayBox;
	private string _temp_name;
	public InputField _Message;

	public Transform _ChatCanvas;


	private Vector3 correctPlayerPos = Vector3.zero; // We lerp towards this
	private Quaternion correctPlayerRot = Quaternion.identity; // We lerp towards this

	public enum EPlayerStatusEnum
	{
		Idle,
		Walk

	}
	public EPlayerStatusEnum ePlayerStatus;

	// Use this for initialization
	void Start () {
		_anim = GetComponent<Animation> ();
		ePlayerStatus = EPlayerStatusEnum.Idle;
		_anim.Play ("Idle");

		myPhotonView = this.gameObject.GetComponent<PhotonView>();

		if (myPhotonView.isMine) {
		//	print ("Player Name : " + PlayerPrefs.GetString ("Player_Name"));
			_temp_name = PlayerPrefs.GetString ("Player_Name");
			_PlayerName.text = _temp_name;
		}

		_ChatCanvas.parent = null;
	}
	
	// Update is called once per frame
	void Update () {

		if (photonView.isMine) {
			Rotate ();
			MovePlayer ();
			PlayAnimations ();
		} else {
			transform.position = correctPlayerPos;
			transform.rotation = correctPlayerRot;		
		}
	}


	public void	PassMessages(){
		myPhotonView.RPC("SendClicked", PhotonTargets.All);
	}

	[PunRPC]
	 void SendClicked(){

		print ("Message in player controller ");
		_PlayerName.text = "RPC Success";
	}

	public void SendMessageToChat(){
		_MessageDisplayBox.text = _Message.text;
	}

	private void PlayAnimations(){
		if (Input.GetKeyDown (KeyCode.W) || Input.GetKeyDown (KeyCode.UpArrow)) {
			_anim.Play ("Walk");
		} else if (Input.GetKeyDown (KeyCode.S) || Input.GetKeyDown (KeyCode.DownArrow)) {
			_anim.Play ("Walk");
		} else if(Input.GetKeyUp (KeyCode.W) || Input.GetKeyUp (KeyCode.UpArrow)|| Input.GetKeyUp (KeyCode.S) || Input.GetKeyUp (KeyCode.DownArrow )){
			_anim.Play ("Idle");
		}

	}

	private void Rotate(){
		if(Input.GetAxis("Horizontal")<0){
			this.transform.Rotate(Vector3.up *-1* speed * Time.deltaTime);
		}else if(Input.GetAxis("Horizontal")>0){
			this.transform.Rotate(Vector3.up * speed * Time.deltaTime);
		}
	}

	private void MovePlayer()
	{
		if(Input.GetAxis("Vertical")<0){
			//print("forward");
			transform.Translate ( Vector3.forward *-1*.5f *Time.deltaTime);
		}else if(Input.GetAxis("Vertical")>0){
			//print("back");
			transform.Translate (Vector3.forward *.5f *Time.deltaTime);
		}
	}

	void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		if (stream.isWriting)
		{
			
			// We own this player: send the others our data
			stream.SendNext(transform.position);
			stream.SendNext(transform.rotation);
			
			//			myThirdPersonController myC = GetComponent<myThirdPersonController>();
			//			stream.SendNext((int)myC._characterState);
		}
		else
		{
			// Network player, receive data
			this.correctPlayerPos = (Vector3)stream.ReceiveNext();
			this.correctPlayerRot = (Quaternion)stream.ReceiveNext();
			
			//			myThirdPersonController myC = GetComponent<myThirdPersonController>();
			//			myC._characterState = (CharacterState)stream.ReceiveNext();
		}
	}

//	public void OnGUI()
//	{
//
//		GUILayout.BeginArea(new Rect(20, Screen.height-110, 350, 200));
//
//		GUI.skin.label.wordWrap = true;
//		//this.userIdInput = GUILayout.TextField(this.userIdInput, GUILayout.MinWidth(100), GUILayout.ExpandWidth(false));
//
//		inputLine = GUILayout.TextField(inputLine, GUILayout.MinWidth(100), GUILayout.ExpandWidth(false));
//
//		if (GUILayout.Button("Send", GUILayout.ExpandWidth(false)))
//		{
//		//	GuiSendsMsg();
//			print("Send Clicked : "+inputLine);
//		//	_ChatBox.text = inputLine;
//			myPhotonView.RPC("SendClicked", PhotonTargets.All, inputLine);
//
//		}
//		GUILayout.EndArea();
//	}
}
